/**
 * Taleos - Helper Société Générale (careers.societegenerale.com)
 * Affiche le bandeau et clique sur "Apply" quand l'automatisation est lancée depuis Taleos
 */
(function() {
  'use strict';

  let currentTabIdPromise = null;
  async function getCurrentTabId() {
    if (!currentTabIdPromise) {
      currentTabIdPromise = chrome.runtime.sendMessage({ action: 'taleos_get_current_tab_id' })
        .then((res) => res?.tabId || null)
        .catch(() => null);
    }
    return currentTabIdPromise;
  }

  async function snapshot(tag, extra = {}) {
    const api = globalThis.__TALEOS_SG_BLUEPRINT__;
    if (!api?.capturePageSnapshot) return;
    await api.capturePageSnapshot(tag, extra);
  }

  async function validateBlueprint(expected, reason) {
    const api = globalThis.__TALEOS_SG_BLUEPRINT__;
    if (!api?.validateExpectedPage) return true;
    const result = await api.validateExpectedPage(expected);
    if (result.ok) return true;
    console.warn('[Taleos SG Careers] Blueprint mismatch:', reason || '', result);
    return false;
  }

  async function validateOfferStructure() {
    const api = globalThis.__TALEOS_SG_BLUEPRINT__;
    if (!api?.validateOfferStructure) return true;
    const result = await api.validateOfferStructure();
    if (result.ok) return true;
    console.warn('[Taleos SG Careers] Offre SG non conforme au blueprint:', result);
    return false;
  }

  const BANNER_ID = 'taleos-sg-automation-banner';
  function showBanner() {
    if (document.getElementById(BANNER_ID)) return;
    const api = globalThis.__TALEOS_AUTOMATION_BANNER__;
    const banner = document.createElement('div');
    banner.id = BANNER_ID;
    banner.textContent = api ? api.getText() : '⏳ Automatisation Taleos en cours — Ne touchez à rien.';
    if (api) api.applyStyle(banner);
    else {
      Object.assign(banner.style, {
        position: 'fixed', top: '0', left: '0', right: '0', zIndex: '2147483647',
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', color: 'white',
        padding: '10px 20px', fontSize: '14px', fontWeight: '600', textAlign: 'center',
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
        boxShadow: '0 2px 10px rgba(0,0,0,0.2)'
      });
    }
    const root = document.body || document.documentElement;
    if (root) (root.firstChild ? root.insertBefore(banner, root.firstChild) : root.appendChild(banner));
  }

  function is404OfferPage() {
    const txt = (document.body?.innerText || document.body?.innerHTML || document.documentElement?.innerHTML || '').toLowerCase();
    return /page not found|page introuvable|erreur 404|error 404|job position is no longer online|the requested page no longer exists|offre d'emploi ne soit plus en ligne|n'existe plus|il semblerait que la page/i.test(txt);
  }

  function urlMatchesOffer(currentUrl, offerUrl) {
    if (!offerUrl || !currentUrl) return false;
    const cur = String(currentUrl).toLowerCase().replace(/\/$/, '');
    const off = String(offerUrl).toLowerCase().replace(/\/$/, '');
    return cur === off || cur.startsWith(off) || off.startsWith(cur) ||
      (cur.includes('careers.societegenerale.com') && off.includes('careers.societegenerale.com'));
  }

  async function run() {
    await snapshot('sg_public_offer_script_start');
    const api = globalThis.__TALEOS_SG_BLUEPRINT__;
    const currentTabId = await getCurrentTabId();
    const { taleos_pending_sg, taleos_sg_tab_id } = await chrome.storage.local.get(['taleos_pending_sg', 'taleos_sg_tab_id']);
    if (!taleos_pending_sg) {
      console.log('[Taleos SG Careers] Pas de candidature en cours (taleos_pending_sg absent).');
      return;
    }
    if (!currentTabId || !taleos_sg_tab_id || currentTabId !== taleos_sg_tab_id) {
      console.log('[Taleos SG Careers] Onglet ouvert manuellement ou non armé → skip.');
      return;
    }
    const age = Date.now() - (taleos_pending_sg.timestamp || 0);
    if (age > 3 * 60 * 1000) {
      chrome.storage.local.remove(['taleos_pending_sg', 'taleos_sg_tab_id']);
      return;
    }

    if (is404OfferPage()) {
      const jobId = taleos_pending_sg?.profile?.__jobId || taleos_pending_sg?.jobId || '';
      const jobTitle = taleos_pending_sg?.profile?.__jobTitle || taleos_pending_sg?.jobTitle || '';
      const offerUrl = taleos_pending_sg?.profile?.__offerUrl || taleos_pending_sg?.offerUrl || '';
      chrome.storage.local.remove(['taleos_pending_sg', 'taleos_sg_tab_id']);
      try {
        if (jobId || offerUrl) {
          chrome.runtime.sendMessage({
            action: 'candidature_failure',
            jobId,
            jobTitle,
            offerUrl,
            error: 'Offre non disponible (404) — L\'offre n\'est plus en ligne.',
            offerExpired: true
          });
        }
      } catch (_) {}
      const banner = document.createElement('div');
      banner.id = BANNER_ID;
      banner.innerHTML = '⛔ Offre non disponible (404) — L\'offre n\'est plus en ligne. Candidature annulée.';
      Object.assign(banner.style, {
        position: 'fixed', top: '0', left: '0', right: '0', zIndex: '2147483647',
        background: 'linear-gradient(135deg, #c53030 0%, #9b2c2c 100%)', color: 'white',
        padding: '12px 20px', fontSize: '14px', fontWeight: '600', textAlign: 'center',
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
        boxShadow: '0 2px 10px rgba(0,0,0,0.2)'
      });
      (document.body?.firstChild ? document.body.insertBefore(banner, document.body.firstChild) : document.body?.appendChild(banner));
      return;
    }

    if (!(await validateBlueprint('public_offer', 'Page offre publique SG non reconnue'))) return;
    if (!(await validateOfferStructure())) return;

    showBanner();
    const delay = ms => new Promise(r => setTimeout(r, ms));

    try {
      const host = document.querySelector('#didomi-host');
      const btn = host?.shadowRoot?.querySelector('#didomi-notice-disagree-button') ||
        document.querySelector('#didomi-notice-disagree-button');
      if (btn) btn.click();
      document.body.style.setProperty('overflow', 'auto', 'important');
    } catch (_) {}
    await delay(2000);

    for (let i = 0; i < 30; i++) {
      const taleoUrl = String(document.querySelector('#taleo_url')?.getAttribute('data-value') || '').trim();
      const matchesApplyUrl = api?.isEquivalentTaleoApplyUrl
        ? (href) => api.isEquivalentTaleoApplyUrl(href, taleoUrl)
        : (href) => href === taleoUrl;
      const btn = Array.from(document.querySelectorAll('a.btnApply[href*="jobapply.ftl"], a[data-gtm-label="postuler"][href*="jobapply.ftl"]'))
        .find((el) => {
          if (el.offsetParent === null) return false;
          const href = String(el.getAttribute('href') || '').trim();
          return taleoUrl ? matchesApplyUrl(href) : /socgen\.taleo\.net\/careersection\/sgcareers\/jobapply\.ftl/i.test(href);
        });
      if (btn && btn.offsetParent !== null) {
        console.log('[Taleos SG Careers] Clic sur Postuler...');
        btn.scrollIntoView({ behavior: 'smooth', block: 'center' });
        await delay(500);
        await snapshot('sg_public_offer_before_apply_click', { taleoUrl });
        btn.click();
        return;
      }
      await delay(500);
    }
    console.warn('[Taleos SG Careers] Bouton Postuler non trouvé après 15s.');
  }

  run().catch(e => console.error('[Taleos SG Careers]', e));
})();
