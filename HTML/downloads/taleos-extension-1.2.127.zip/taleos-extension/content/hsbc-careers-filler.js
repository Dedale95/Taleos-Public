/**
 * Taleos — HSBC Careers Filler
 * Remplit le formulaire SAP SuccessFactors HSBC (career2.successfactors.eu, company=hsbcholdin).
 *
 * Flux couvert :
 *   1. Page offre Eightfold (portal.careers.hsbc.com) → clic automatique Apply → SF listing
 *   2. SF listing (career2.successfactors.eu/careers?…) → clic automatique Apply → SF form
 *   3. SF form (career2.successfactors.eu/career?…)    → remplissage complet (sans mot de passe)
 *
 * Source données :  chrome.storage.local.taleos_pending_hsbc.profile
 * Upload CV :       chrome.runtime.sendMessage({ action: 'fetch_storage_file', storagePath })
 *
 * IMPORTANT : ne soumet jamais (#fbqa_apply n'est jamais cliqué automatiquement).
 * Le candidat entre son mot de passe et soumet manuellement.
 *
 * Noms de fichiers : utilise exactement cv_filename / letter_filename tels que stockés dans Firebase
 * (pas de renommage).
 */
(async () => {
  'use strict';

  // ══════════════════════════════════════════════════════════════════════════════
  // 0. Garde-fous et initialisation
  // ══════════════════════════════════════════════════════════════════════════════
  if (globalThis.__TALEOS_HSBC_FILLER_RUNNING__) return;
  globalThis.__TALEOS_HSBC_FILLER_RUNNING__ = true;

  const BANNER_ID     = 'taleos-hsbc-banner';
  const STORAGE_KEY   = 'taleos_pending_hsbc';
  const TAB_ID_KEY    = 'taleos_hsbc_tab_id';
  const isTop         = window === window.top;
  const blueprint     = globalThis.__TALEOS_HSBC_BLUEPRINT__ || null;

  // ══════════════════════════════════════════════════════════════════════════════
  // 1. Utilitaires de base
  // ══════════════════════════════════════════════════════════════════════════════
  function log(msg) {
    const line = `[HSBC Filler] ${msg}`;
    console.log(line);
    try {
      chrome.runtime.sendMessage({
        action: 'extension_run_log',
        source: 'hsbc-careers-filler',
        level: 'info',
        message: String(msg),
        ts: new Date().toISOString()
      }).catch(() => {});
    } catch (_) {}
  }

  function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
  }

  async function waitFor(fn, timeoutMs = 6000, intervalMs = 250) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      try {
        const result = fn();
        if (result) return result;
      } catch (_) {}
      await sleep(intervalMs);
    }
    return null;
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // 2. Récupération du profil
  // ══════════════════════════════════════════════════════════════════════════════
  async function getCurrentTabId() {
    try {
      const res = await chrome.runtime.sendMessage({ action: 'taleos_get_current_tab_id' });
      return res?.tabId || null;
    } catch (_) { return null; }
  }

  async function getPendingEntry() {
    const currentTabId = await getCurrentTabId();
    const stored = await chrome.storage.local.get([STORAGE_KEY, TAB_ID_KEY]);
    const entry = stored[STORAGE_KEY];
    if (!entry?.profile) return null;
    const expectedTabId = entry.tabId || stored[TAB_ID_KEY] || null;
    if (currentTabId && expectedTabId && currentTabId !== expectedTabId) return null;
    return entry;
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // 3. Normalisation du profil
  // ══════════════════════════════════════════════════════════════════════════════
  function normalizeProfile(raw) {
    // phone_number provient de background.js (déjà sans indicatif ni 0 initial)
    const phone     = String(raw.phone_number || raw['phone-number'] || raw.phone || '').replace(/\D/g, '');
    const phoneCode = String(raw.phone_country_code || '+33').trim();

    // Genre : mappe vers les options exactes du formulaire SF HSBC
    const genderRaw = String(raw.gender || '').trim();
    let gender = 'Prefer not to say';
    if (/^male$/i.test(genderRaw))   gender = 'Male';
    if (/^female$/i.test(genderRaw)) gender = 'Female';

    return {
      firstName:      String(raw.firstname || raw.first_name || '').trim(),
      lastName:       String(raw.lastname  || raw.last_name  || '').trim(),
      email:          String(raw.email     || raw.auth_email || '').trim(),
      phoneCode,
      phone,
      gender,
      // Fichiers — noms exacts Firebase (ne pas renommer)
      cvStoragePath:  String(raw.cv_storage_path || '').trim(),
      cvFilename:     String(raw.cv_filename      || 'cv.pdf').trim(),
    };
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // 4. Bannière Taleos
  // ══════════════════════════════════════════════════════════════════════════════
  function activateTab() {
    chrome.runtime.sendMessage({ action: 'hsbc_activate_tab' }).catch(() => {});
  }

  function showBanner(text, type = 'info') {
    const api = globalThis.__TALEOS_AUTOMATION_BANNER__;
    let el = document.getElementById(BANNER_ID);
    if (!el) {
      el = document.createElement('div');
      el.id = BANNER_ID;
      if (api) {
        api.applyStyle(el);
      } else {
        Object.assign(el.style, {
          position: 'fixed', top: '0', left: '0', right: '0',
          zIndex: '2147483647', background: '#1a3c6e', color: '#fff',
          padding: '8px 16px', fontSize: '13px', fontFamily: 'sans-serif',
          borderBottom: '2px solid #c8a951', textAlign: 'center'
        });
      }
      document.body.prepend(el);
    }
    if (type === 'success') el.style.background = '#155724';
    if (type === 'warn')    el.style.background = '#856404';
    if (type === 'error')   el.style.background = '#721c24';
    el.textContent = `🏦 Taleos HSBC — ${text}`;
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // 5. Remplissage des champs texte
  // ══════════════════════════════════════════════════════════════════════════════
  function setNativeValue(el, value) {
    if (!el) return;
    const proto = el.tagName === 'TEXTAREA'
      ? window.HTMLTextAreaElement.prototype
      : window.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) {
      setter.call(el, value);
    } else {
      el.value = value;
    }
    el.dispatchEvent(new Event('input',  { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur',   { bubbles: true }));
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // 6. PaginatedPicklist (widgets SF hors select natif)
  // ══════════════════════════════════════════════════════════════════════════════

  /**
   * Ouvre un paginatedPicklist et sélectionne la valeur cible.
   *
   * Mécanisme SF :
   *   - Chaque widget a un input (N:_input), un bouton (N:_selectButton)
   *   - aria-owns sur l'input → "(N+1):_listSelect" quand la liste est ouverte
   *   - Les options sont des [role="option"] dans cette liste
   */
  async function selectPicklist(inputEl, targetValue, label = '') {
    if (!inputEl) { log(`⚠️ Picklist "${label}" introuvable`); return false; }

    const btnId  = inputEl.id.replace(':_input', ':_selectButton');
    const btn    = document.getElementById(btnId);
    if (btn) btn.click();
    else inputEl.click();

    // Attendre que aria-owns soit défini (liste créée)
    const listId = await waitFor(() => inputEl.getAttribute('aria-owns'), 4000, 150);
    if (!listId) { log(`⚠️ Picklist "${label}" : liste non ouverte`); return false; }

    // Attendre que des options apparaissent
    const list = await waitFor(() => {
      const el = document.getElementById(listId);
      return (el && el.querySelectorAll('[role="option"]').length > 0) ? el : null;
    }, 5000, 200);

    if (!list) { log(`⚠️ Picklist "${label}" : options non chargées`); return false; }

    const options = Array.from(list.querySelectorAll('[role="option"]'));
    const target  = options.find(o => o.textContent.trim() === targetValue);
    if (!target) {
      log(`⚠️ Picklist "${label}" : option "${targetValue}" introuvable. Disponibles : ${options.map(o => o.textContent.trim()).join(' | ')}`);
      return false;
    }

    target.click();
    log(`✅ ${label || 'Picklist'} → "${targetValue}"`);
    return true;
  }

  /**
   * Sélectionne l'indicatif téléphonique en tapant dans le champ (filtrage de la liste).
   * Le champ 9:_input est un combobox avec > 200 options — on filtre par saisie.
   */
  async function selectCallingCode(code) {
    const input = document.getElementById('9:_input');
    if (!input) { log('⚠️ Champ indicatif (9:_input) introuvable'); return false; }

    setNativeValue(input, code);
    await sleep(700); // laisser le filtre s'appliquer

    const listId = input.getAttribute('aria-owns');
    const list   = listId ? document.getElementById(listId) : null;
    if (!list) { log(`⚠️ Indicatif : liste non trouvée`); return false; }

    const options = Array.from(list.querySelectorAll('[role="option"]'));
    const target  = options.find(o => o.textContent.trim() === code);
    if (target) {
      target.click();
      log(`✅ Indicatif → "${code}"`);
      return true;
    }

    // Fallback : premier résultat si le code exact n'est pas là (ex. "+33" vs "+33 France")
    if (options.length > 0 && options[0].textContent.trim().startsWith(code)) {
      options[0].click();
      log(`✅ Indicatif (approx.) → "${options[0].textContent.trim()}"`);
      return true;
    }

    log(`⚠️ Indicatif "${code}" non trouvé dans la liste filtrée`);
    return false;
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // 7. Upload CV depuis Firebase Storage
  // ══════════════════════════════════════════════════════════════════════════════
  async function uploadCV(storagePath, filename) {
    if (!storagePath) { log('⚠️ cv_storage_path absent — CV non uploadé'); return false; }

    // Ouvrir le widget d'upload
    const attachIcon = document.getElementById('59:_attachIcon');
    if (!attachIcon) { log('⚠️ Bouton upload CV (59:_attachIcon) introuvable'); return false; }
    attachIcon.click();
    await sleep(800);

    // Attendre l'input file
    const fileInput = await waitFor(
      () => document.getElementById('60:_file') || document.querySelector('input[name="fileData1"]'),
      4000
    );
    if (!fileInput) { log('⚠️ Input file CV introuvable après ouverture du widget'); return false; }

    // Télécharger depuis Firebase via background.js
    log(`⏳ Téléchargement CV depuis Firebase : ${storagePath}`);
    const r = await chrome.runtime.sendMessage({ action: 'fetch_storage_file', storagePath }).catch(() => null);
    if (!r?.base64) { log(`⚠️ CV introuvable dans Firebase Storage (${storagePath})`); return false; }

    // Construire le File avec le nom exact Firebase (pas de renommage)
    const bin = atob(r.base64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    const effectiveFilename = String(filename || r.filename || 'cv.pdf').trim();
    const file = new File([bytes], effectiveFilename, { type: r.type || 'application/pdf' });

    const dt = new DataTransfer();
    dt.items.add(file);
    fileInput.files = dt.files;
    fileInput.dispatchEvent(new Event('change', { bubbles: true }));
    fileInput.dispatchEvent(new Event('input',  { bubbles: true }));

    // Attendre confirmation d'upload (59:_attachSuccess visible)
    const success = await waitFor(() => {
      const el = document.getElementById('59:_attachSuccess');
      return el && !el.classList.contains('displayNone') ? el : null;
    }, 20000, 500);

    if (success) {
      log(`✅ CV uploadé : ${effectiveFilename}`);
      return true;
    }

    // Vérification alternative : fbja_uploadedResumeId rempli
    const uploadedId = document.getElementById('fbja_uploadedResumeId');
    if (uploadedId?.value) {
      log(`✅ CV uploadé (via fbja_uploadedResumeId) : ${effectiveFilename}`);
      return true;
    }

    log(`⚠️ Timeout upload CV — vérifiez manuellement (${effectiveFilename})`);
    return false;
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // 8. Acceptation de la politique de confidentialité
  // ══════════════════════════════════════════════════════════════════════════════
  async function acceptPrivacy() {
    const link = document.getElementById('dataPrivacyId');
    if (!link) { log('⚠️ Lien confidentialité (dataPrivacyId) introuvable'); return false; }

    // Cliquer le lien ouvre une modale avec boutons "Accept" / "Decline" / "Print"
    link.click();
    await sleep(800);

    // Chercher le bouton "Accept" dans la modale
    const acceptBtn = await waitFor(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      return btns.find(b => b.textContent.trim() === 'Accept') || null;
    }, 4000, 200);

    if (acceptBtn) {
      acceptBtn.click();
      await sleep(500);
      log('✅ Politique de confidentialité → bouton "Accept" cliqué');
    } else {
      log('⚠️ Bouton "Accept" non trouvé dans la modale — tentative fallback');
    }

    // Vérifier l'acceptation : fbclc_dpcsId non vide + texte de confirmation
    const dpcsInput = document.getElementById('fbclc_dpcsId');
    if (dpcsInput?.value) {
      log(`✅ Politique acceptée (fbclc_dpcsId="${dpcsInput.value}")`);
    } else if (dpcsInput) {
      // Fallback : forcer si la modale n'a pas pu être cliquée
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
      if (setter) setter.call(dpcsInput, '1');
      dpcsInput.dispatchEvent(new Event('change', { bubbles: true }));
      log('✅ Politique de confidentialité acceptée (fbclc_dpcsId forcé à "1")');
    }

    return true;
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // 9. Remplissage du formulaire principal (SF new-user application form)
  // ══════════════════════════════════════════════════════════════════════════════
  async function fillApplicationForm(profile) {
    const p = normalizeProfile(profile);
    log(`Début remplissage pour ${p.firstName} ${p.lastName} <${p.email}>`);
    showBanner('Remplissage en cours…');

    // Attendre que le formulaire soit prêt (jusqu'à 10s)
    // fbclc_userName = champ email du formulaire nouveau compte (non connecté)
    // Pour un utilisateur déjà connecté (/portalcareer), ce champ est absent — on continue quand même
    await sleep(600);
    const emailField = document.getElementById('fbclc_userName');

    if (emailField) {
      // ── Identifiants (formulaire nouveau compte) ──
      setNativeValue(emailField, p.email);
      await sleep(150);
      const emailConf = document.getElementById('fbclc_emailConf');
      if (emailConf) setNativeValue(emailConf, p.email);
      log(`✅ Email → ${p.email}`);
    } else {
      log('ℹ️ fbclc_userName absent — utilisateur déjà connecté, remplissage partiel du formulaire');
      showBanner('Connecté — remplissage du formulaire en cours…');
    }

    // ── Noms ────────────────────────────────────────────────────────────────────
    const fName = document.getElementById('fbclc_fName');
    if (fName) { setNativeValue(fName, p.firstName); log(`✅ Prénom légal → ${p.firstName}`); }

    const lName = document.getElementById('fbclc_lName');
    if (lName) { setNativeValue(lName, p.lastName); log(`✅ Nom légal → ${p.lastName}`); }

    const prefName = document.getElementById('tor__fcust_PrefFName');
    if (prefName) { setNativeValue(prefName, p.firstName); log(`✅ Prénom préféré → ${p.firstName}`); }

    // ── Téléphone ────────────────────────────────────────────────────────────────
    await sleep(300);
    await selectCallingCode(p.phoneCode);
    await sleep(200);
    const phoneField = document.getElementById('tor__fcellPhone');
    if (phoneField) { setNativeValue(phoneField, p.phone); log(`✅ Téléphone → ${p.phone}`); }

    // ── Questions HSBC spécifiques ────────────────────────────────────────────────
    await sleep(400);
    // Proches travaillant chez HSBC → Non
    await selectPicklist(document.getElementById('13:_input'), 'No', 'Proches HSBC');
    await sleep(350);

    // Ancien employé / prestataire → Non
    await selectPicklist(document.getElementById('17:_input'), 'No', 'Ancien employé HSBC');
    await sleep(350);

    // Genre
    await selectPicklist(document.getElementById('21:_input'), p.gender, 'Genre');
    await sleep(350);

    // Droit au travail dans le pays → Oui
    await selectPicklist(document.getElementById('25:_input'), 'Yes', 'Droit au travail');
    await sleep(350);

    // Employé par les auditeurs externes HSBC → Non
    await selectPicklist(document.getElementById('29:_input'), 'No', "Auditeurs externes HSBC");
    await sleep(350);

    // ── Pays ─────────────────────────────────────────────────────────────────────
    const countrySelect = document.getElementById('fbclc_country');
    if (countrySelect) {
      const franceOpt = Array.from(countrySelect.options).find(o => o.text === 'France');
      if (franceOpt) {
        countrySelect.value = franceOpt.value;
        countrySelect.dispatchEvent(new Event('change', { bubbles: true }));
        log('✅ Pays → France');
      } else {
        log("⚠️ Option 'France' introuvable dans le select pays");
      }
    }

    // ── Visibilité du profil → "Only recruiters managing jobs I apply to" (value=2) ──
    const searPrefRadios = document.querySelectorAll('input[name="fbclc_searPref"]');
    for (const r of searPrefRadios) {
      if (r.value === '2') {
        r.checked = true;
        r.dispatchEvent(new Event('change', { bubbles: true }));
        log('✅ Visibilité profil → recruteurs gérant les offres auxquelles je postule uniquement');
        break;
      }
    }

    // ── Notifications email → décocher (profil discret) ──────────────────────────
    const emailNotif = document.getElementById('fbclc_emailEnabled');
    if (emailNotif?.checked) {
      emailNotif.click();
      log('✅ Notifications email → décochées');
    }

    // ── Upload CV ────────────────────────────────────────────────────────────────
    await sleep(500);
    if (p.cvStoragePath) {
      await uploadCV(p.cvStoragePath, p.cvFilename);
    } else {
      log('⚠️ cv_storage_path absent dans le profil — uploadez le CV manuellement');
    }

    // ── Politique de confidentialité ──────────────────────────────────────────────
    await sleep(500);
    await acceptPrivacy();

    // ── Fin ───────────────────────────────────────────────────────────────────────
    log('✅ Formulaire rempli — entrez votre mot de passe puis cliquez Appliquer');
    showBanner(
      '✅ Rempli — entrez votre mot de passe puis cliquez "Apply" pour envoyer',
      'success'
    );
    activateTab(); // amener l'onglet en avant-plan pour que l'utilisateur voie le formulaire
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // 10. Gestion des pages SF listing et Eightfold (clic automatique Apply)
  // ══════════════════════════════════════════════════════════════════════════════
  async function handleListingPage(profile) {
    log('Page listing SF HSBC — attente bouton Apply…');
    showBanner('Ouverture du formulaire de candidature…');

    const applyBtn = await waitFor(
      () =>
        document.getElementById('applyButton_top') ||
        document.getElementById('applyButton_bottom') ||
        document.querySelector('[data-test-id="apply-button"]') ||
        document.querySelector('[class*="position-apply-button"]') ||
        Array.from(document.querySelectorAll('button')).find(b =>
          /apply|postuler|candidater/i.test(b.textContent)
        ),
      10000
    );
    if (!applyBtn) {
      log('⚠️ Bouton Apply introuvable sur la page SF listing');
      showBanner('Bouton Apply non trouvé — cliquez manuellement', 'warn');
      activateTab();
      return;
    }

    applyBtn.click();
    log('✅ Clic Apply → navigation vers le formulaire candidature');
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // Cas Login page : connexion avec identifiants existants
  // ══════════════════════════════════════════════════════════════════════════════
  async function handleLoginPage(profile, offerUrl) {
    log('Page Sign In SF HSBC — connexion avec identifiants enregistrés…');
    showBanner('Connexion à votre compte HSBC…');

    const emailInput = await waitFor(
      () =>
        document.getElementById('username') ||
        document.querySelector('input[name="logonID"]') ||
        document.querySelector('input[autocomplete="username"]') ||
        document.querySelector('input[type="email"]') ||
        document.querySelector('input[name="email"]') ||
        document.querySelector('input[id*="email" i]') ||
        document.querySelector('input[placeholder*="email" i]') ||
        // Formulaire "Career Opportunities: Sign In" (HSBC SF loginFlowRequired)
        document.querySelector('input[id*="user" i]:not([type="hidden"])') ||
        Array.from(document.querySelectorAll('input:not([type="password"]):not([type="hidden"])')).find(
          el => /email|user|login/i.test(el.id + el.name + el.placeholder)
        ),
      8000
    );
    const pwdInput = await waitFor(
      () => document.getElementById('password') || document.querySelector('input[type="password"]'),
      8000
    );

    if (!emailInput || !pwdInput) {
      log('⚠️ Champs email/mot de passe introuvables sur la page Sign In');
      showBanner('Champs de connexion non trouvés — remplissez manuellement', 'warn');
      return;
    }

    setNativeValue(emailInput, profile.auth_email);
    await sleep(300);
    setNativeValue(pwdInput, profile.auth_password || '');
    await sleep(300);

    const submitBtn =
      document.querySelector('button[onclick*="validateFields"]') ||
      document.querySelector('.aquabtn.active button, .button_row button') ||
      Array.from(document.querySelectorAll('button')).find(b => /sign in/i.test(b.textContent));

    if (!submitBtn) {
      log('⚠️ Bouton Sign In introuvable');
      showBanner('Bouton Sign In non trouvé — cliquez manuellement', 'warn');
      return;
    }

    submitBtn.click();
    log('✅ Clic Sign In → attente connexion');
    showBanner('Connexion en cours…');

    // Attendre que la page de connexion disparaisse (succès) OU qu'un message d'erreur apparaisse
    const loginResult = await waitFor(() => {
      const errorEl = document.querySelector('#errorMsg_1, #uiErrorMsg, #uiErrorContainer_2');
      if (errorEl && errorEl.offsetParent !== null) {
        return { error: errorEl.innerText?.trim() || 'Identifiants incorrects' };
      }
      // Succès : champ email disparu ou URL changée
      const loginForm = document.querySelector('#username') || document.querySelector('input[name="logonID"]');
      if (!loginForm || loginForm.offsetParent === null) {
        return { success: true };
      }
      return null; // En attente
    }, 12000, 400);

    if (loginResult?.error) {
      log(`❌ Connexion échouée : ${loginResult.error}`);
      showBanner(`Connexion HSBC échouée : ${loginResult.error}`, 'error');
      return;
    }

    log('✅ Connexion HSBC réussie');

    if (!offerUrl) {
      showBanner('Connecté ! Naviguez manuellement vers l\'offre HSBC', 'warn');
      return;
    }

    log(`→ Navigation vers l'offre : ${offerUrl}`);
    showBanner('Connecté ! Ouverture de l\'offre…');
    await sleep(600);
    location.href = offerUrl;
  }

  /**
   * Construit l'URL SF depuis le champ ats_job_id du JSON Eightfold.
   *
   * La page Eightfold (portal.careers.hsbc.com) contient un <script> JSON avec :
   *   { "positions": [{ "ats_job_id": "44076", ... }] }
   *
   * ats_job_id = career_job_req_id dans SF → on construit directement l'URL
   * de la fiche poste SF, que le filler peut traiter via handleListingPage
   * (clic Apply sur SF ne demande pas isTrusted, ouvre le form dans le même onglet).
   */
  function extractSFApplyUrl() {
    try {
      // 1. Chercher ats_job_id dans TOUS les scripts (inline + JSON)
      for (const s of document.querySelectorAll('script')) {
        if (s.src) continue;
        const text = s.textContent || '';
        if (!text.includes('ats_job_id')) continue;
        const m = text.match(/"ats_job_id"\s*:\s*"(\d+)"/);
        if (m && m[1]) {
          const sfUrl = `https://career2.successfactors.eu/career?company=hsbcholdin&career_ns=job_listing&navBarLevel=JOB_DETAIL&rcm_site_locale=en_GB&career_job_req_id=${m[1]}`;
          log(`ats_job_id=${m[1]} trouvé → URL SF : ${sfUrl}`);
          return sfUrl;
        }
      }
      // 2. Chercher dans le HTML brut (fallback si le script est dynamique)
      const bodyHtml = document.documentElement.innerHTML;
      const m2 = bodyHtml.match(/"ats_job_id"\s*:\s*"(\d+)"/);
      if (m2 && m2[1]) {
        const sfUrl = `https://career2.successfactors.eu/career?company=hsbcholdin&career_ns=job_listing&navBarLevel=JOB_DETAIL&rcm_site_locale=en_GB&career_job_req_id=${m2[1]}`;
        log(`ats_job_id=${m2[1]} (fallback HTML) → URL SF : ${sfUrl}`);
        return sfUrl;
      }
      // 3. Chercher une URL SF complète déjà présente dans la page (ancien comportement)
      for (const s of document.querySelectorAll('script:not([src])')) {
        const m = s.textContent?.match(/https:\/\/career2\.successfactors\.eu\/[^"'\\]+hsbcholdin[^"'\\]*/);
        if (m) return m[0].replace(/\\u0026/g, '&');
      }
    } catch (_) {}
    return null;
  }

  async function handleEightfoldOffer(profile) {
    log('Page offre Eightfold HSBC — extraction ats_job_id…');
    showBanner('Récupération du lien de candidature SF…');

    // Attendre que le JSON Eightfold soit chargé dans la page (max 6s)
    let sfUrl = null;
    const deadline = Date.now() + 6000;
    while (!sfUrl && Date.now() < deadline) {
      sfUrl = extractSFApplyUrl();
      if (!sfUrl) await sleep(300);
    }

    if (sfUrl) {
      log(`✅ URL SF construite depuis ats_job_id → navigation : ${sfUrl}`);
      showBanner('Redirection vers la fiche poste SF…');
      await sleep(400);
      location.href = sfUrl;
    } else {
      log('⚠️ ats_job_id introuvable dans la page Eightfold');
      showBanner('Lien SF non trouvé — cliquez manuellement sur Postulez maintenant', 'warn');
      activateTab();
    }
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // 11. Gestion de la page apply.careers.hsbc.com (intermédiaire HSBC)
  // ══════════════════════════════════════════════════════════════════════════════
  /**
   * apply.careers.hsbc.com/job/TITLE/JOB_ID/
   *
   * Cette page est un intermédiaire entre la fiche SF listing et le formulaire de
   * candidature. Elle affiche un bouton "POSTULER". Stratégie :
   *
   *  1. Chercher ats_job_id dans le HTML (peut-être présent comme sur Eightfold)
   *  2. Extraire l'ID numérique du path URL et l'essayer comme career_job_req_id SF
   *  3. Chercher le bouton/lien POSTULER et naviguer via son href (si c'est un <a>)
   *  4. Fallback : clic programmatique sur le bouton
   */
  async function handleApplyCareerPage(profile) {
    log('Page apply.careers.hsbc.com — extraction du lien SF…');
    showBanner('Récupération du lien de candidature…');

    // 1. Chercher ats_job_id dans la page (même méthode que Eightfold)
    let sfUrl = null;
    const deadline1 = Date.now() + 4000;
    while (!sfUrl && Date.now() < deadline1) {
      sfUrl = extractSFApplyUrl();
      if (!sfUrl) await sleep(300);
    }

    if (sfUrl) {
      log(`✅ URL SF via ats_job_id → navigation : ${sfUrl}`);
      showBanner('Redirection vers la fiche poste SF…');
      await sleep(400);
      location.href = sfUrl;
      return;
    }

    // 2. Essayer l'ID numérique de l'URL comme career_job_req_id
    // URL format : /job/TITLE-SLUG/1360785157/
    const urlIdMatch = location.pathname.match(/\/job\/[^/]+\/(\d+)\/?$/);
    if (urlIdMatch && urlIdMatch[1]) {
      const jobId = urlIdMatch[1];
      const candidateSfUrl = `https://career2.successfactors.eu/career?company=hsbcholdin&career_ns=job_listing&navBarLevel=JOB_DETAIL&rcm_site_locale=en_GB&career_job_req_id=${jobId}`;
      log(`ID URL détecté (${jobId}) → tentative URL SF : ${candidateSfUrl}`);
      showBanner('Redirection vers la fiche poste SF…');
      await sleep(400);
      location.href = candidateSfUrl;
      return;
    }

    // 3. Chercher le bouton/lien POSTULER et naviguer via son href si disponible
    const applyEl = await waitFor(() => {
      const all = Array.from(document.querySelectorAll('a, button'));
      return all.find(el => /postuler|apply\s*now|candidater/i.test(el.textContent.trim())) || null;
    }, 8000);

    if (!applyEl) {
      log('⚠️ Bouton POSTULER introuvable sur apply.careers.hsbc.com');
      showBanner('Bouton POSTULER non trouvé — cliquez manuellement', 'warn');
      activateTab();
      return;
    }

    // Si c'est un lien (<a href="...">) → naviguer directement sans déclencher d'évènement
    const href = applyEl.tagName === 'A'
      ? (applyEl.getAttribute('href') || '')
      : (applyEl.dataset?.href || applyEl.getAttribute('data-url') || '');

    if (href && (href.startsWith('http') || href.startsWith('/'))) {
      const target = href.startsWith('http') ? href : new URL(href, location.origin).href;
      log(`✅ Lien POSTULER href="${target}" → navigation directe`);
      showBanner('Ouverture du formulaire de candidature…');
      await sleep(300);
      location.href = target;
      return;
    }

    // 4. Fallback : clic programmatique (apply.careers.hsbc.com peut ne pas vérifier isTrusted)
    log('Clic programmatique sur le bouton POSTULER…');
    showBanner('Ouverture du formulaire de candidature…');
    applyEl.click();
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // 12. Point d'entrée principal
  // ══════════════════════════════════════════════════════════════════════════════
  async function main() {
    // Détection de la page via le blueprint
    const page = blueprint?.detectPage?.();
    if (!page) {
      // Vérification manuelle minimale : on est sur HSBC SF, Eightfold ou apply.careers.hsbc.com ?
      const host = location.hostname;
      const href = location.href;
      const isHsbcHost = host.includes('career2.successfactors.eu')
        || host.includes('portal.careers.hsbc.com')
        || host.includes('apply.careers.hsbc.com');
      if (!isHsbcHost) return;
      if (!href.includes('hsbcholdin') && !host.includes('portal.careers.hsbc.com') && !host.includes('apply.careers.hsbc.com')) return;
    }

    const entry = await getPendingEntry();
    if (!entry?.profile) {
      log('Aucun profil HSBC en attente (taleos_pending_hsbc absent ou tab non correspondant)');
      return;
    }

    const { profile } = entry;
    const host = location.hostname;
    const path = location.pathname;
    const href = location.href;

    // Cas 0 : page de confirmation post-soumission — ne rien faire, effacer le pending
    // URL réelle : /portalcareer?isRedirectToAppSent=true&isQuickApplyPostLoginRedirect=true
    if (href.includes('isRedirectToAppSent=true') || href.includes('isQuickApplyPostLoginRedirect=true')) {
      log('✅ Candidature HSBC confirmée — nettoyage du pending');
      chrome.storage.local.remove([STORAGE_KEY, TAB_ID_KEY]).catch(() => {});
      showBanner('Candidature envoyée avec succès ! 🎉', 'success');
      return;
    }

    // Cas 0.5 : page profil SF (déjà connecté, loginFlowRequired a redirigé vers MY_PROFILE)
    // → naviguer directement vers l'offre Eightfold dans le même onglet
    const isProfilePage = host.includes('career2.successfactors.eu')
      && href.includes('navBarLevel=MY_PROFILE');

    if (isProfilePage) {
      const targetUrl = entry.offerUrl || '';
      if (targetUrl) {
        log(`Déjà connecté (page profil) → navigation vers l'offre : ${targetUrl}`);
        showBanner('Déjà connecté — ouverture de l\'offre…');
        await sleep(500);
        location.href = targetUrl;
      } else {
        log('Déjà connecté mais offerUrl absent — rien à faire');
        showBanner('Connecté. Naviguez vers l\'offre manuellement.', 'warn');
        activateTab();
      }
      return;
    }

    // Cas 1 : page Sign In SF (utilisateur qui a déjà un compte HSBC)
    // Détecte aussi loginFlowRequired=true (URL ouverte par le background) quand SF n'est pas encore connecté
    const isLoginPage = host.includes('career2.successfactors.eu')
      && (href.includes('login_ns=login') || href.includes('loginFlowRequired=true'))
      && href.includes('hsbcholdin');

    if (isLoginPage) {
      if (profile.auth_email) {
        await handleLoginPage(profile, entry.offerUrl || '');
      } else {
        log('Page Sign In HSBC — pas d\'identifiants configurés dans Connexions. Connectez-vous manuellement ou créez un compte.');
        showBanner('Connectez-vous à votre compte HSBC pour continuer', 'warn');
        activateTab();
      }
      return;
    }

    // Cas 2 : formulaire candidature SF
    // Couvre /career (nouveau compte) et /portalcareer (utilisateur déjà connecté)
    const isSFForm = host.includes('career2.successfactors.eu')
      && (path.startsWith('/career') || path.startsWith('/portalcareer'))
      && !href.includes('career_ns=job_listing')
      && !href.includes('career_ns=job_search')
      && !href.includes('login_ns=login')
      && !href.includes('loginFlowRequired=true')
      && !href.includes('navBarLevel=MY_PROFILE');

    if (isSFForm) {
      await fillApplicationForm(profile);
      return;
    }

    // Cas 3 : page listing SF (avant clic Apply)
    // Large, mais les exclusions ci-dessus (login, profil, form) couvrent déjà les faux positifs
    const isSFListing = host.includes('career2.successfactors.eu')
      && href.includes('hsbcholdin')
      && !href.includes('login_ns=login')
      && !href.includes('navBarLevel=MY_PROFILE')
      && !path.startsWith('/portalcareer');

    if (isSFListing) {
      await handleListingPage(profile);
      return;
    }

    // Cas 4 : page intermédiaire apply.careers.hsbc.com (ex. /job/TITLE/ID/)
    // Cette page apparaît quand la fiche SF listing redirige vers le portail apply HSBC.
    if (host.includes('apply.careers.hsbc.com')) {
      await handleApplyCareerPage(profile);
      return;
    }

    // Cas 5 : page offre Eightfold (portal.careers.hsbc.com)
    // On ne restreint pas le path pour couvrir tous les formats d'URL Eightfold
    if (host.includes('portal.careers.hsbc.com')) {
      await handleEightfoldOffer(profile);
      return;
    }

    log(`Page non reconnue pour le flux HSBC : ${href}`);
  }

  // Lancer avec un léger délai pour laisser le DOM se stabiliser
  await sleep(800);
  await main();
})();
